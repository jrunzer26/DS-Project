source Env/bin/activate
python TodoistRPC.py
