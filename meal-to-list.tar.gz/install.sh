sudo apt-get install build-essential checkinstall nodejs python npm python-pip libzmq-dev
ln -s /usr/bin/nodejs /usr/bin/node
pip install todoist-python
pip install zerorpc

